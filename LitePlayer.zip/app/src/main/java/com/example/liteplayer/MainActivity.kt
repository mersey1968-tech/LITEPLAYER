package com.example.liteplayer

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.KeyEvent
import android.widget.Button
import android.widget.TextView
import android.widget.LinearLayout
import android.os.Handler
import android.os.Looper
import java.security.MessageDigest
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioTrackAudioOutputProvider
import com.example.liteplayer.audio.IecAudioOutputProvider
import androidx.media3.exoplayer.audio.AudioCapabilities
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.video.VideoFrameMetadataListener
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var singleSubtitleView: SubtitleView
    private lateinit var openButton: Button
    private lateinit var infoText: TextView
    private lateinit var subtitleButton: Button
    private lateinit var revealControls: View
    private lateinit var controlPanel: LinearLayout
    private lateinit var playPauseButton: Button
    private lateinit var rewindButton: Button
    private lateinit var forwardButton: Button
    private lateinit var seekSettingsButton: Button
    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressSaver = object : Runnable {
        override fun run() {
            saveProgress()
            progressHandler.postDelayed(this, 5000L)
        }
    }
    private val hideControls = Runnable { concealControls() }
    private var player: ExoPlayer? = null
    private var audioDecoderName = "not reported"
    private var audioInputFormat = "not selected"
    private val diagnosticEvents = ArrayDeque<String>()
    private fun recordEvent(message: String) {
        val line = "${android.os.SystemClock.elapsedRealtime() / 1000}s: $message"
        android.util.Log.i("LitePlayerDiagnostics", line)
        diagnosticEvents.addLast(line)
        while (diagnosticEvents.size > 18) diagnosticEvents.removeFirst()
    }
    private val audioAnalytics = object : AnalyticsListener {
        override fun onAudioDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long
        ) {
            audioDecoderName = decoderName
            recordEvent("Audio decoder initialized: $decoderName")
        }
    }


    private var uri: Uri? = null
    private var position = 0L
    private var playWhenReady = true

    @Volatile private var videoFps = 0f
    @Volatile private var estimateDone = false
    private val frameTimes = ArrayList<Long>()

    private var activeIdentity: String? = null
    private var externalStartPosition = 0L
    private var lastKnownDuration = 0L
    private var launchedExternally = false
    private var ended = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) {
        if (it == null) {
            openButton.visibility = View.VISIBLE
            return@registerForActivityResult
        }
        it.let { picked ->
            runCatching {
                contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            releasePlayer()
            uri = picked; activeIdentity = identityFor(picked, null); position = restoredPosition(picked); playWhenReady = true; ended = false
            recordEvent("Picker restored position=$position ms")
            startPlayer()
        }
    }

    // Fallback for streams that don't declare a frame rate: measure it from the first decoded frames.
    private val frameListener = VideoFrameMetadataListener { pts, _, _, _ ->
        if (!estimateDone && videoFps <= 0f) {
            var fps = 0f
            synchronized(frameTimes) {
                frameTimes.add(pts)
                if (frameTimes.size >= 48) {
                    val sorted = frameTimes.sorted()
                    val span = sorted.last() - sorted.first()
                    if (span > 0) fps = snapFps((sorted.size - 1) * 1_000_000f / span)
                    frameTimes.clear()
                    estimateDone = true
                }
            }
            val found = fps
            if (found > 0f) runOnUiThread { videoFps = found; applyFrameRate() }
        }
    }

    // One subtitle surface owns every cue. PlayerView's built-in subtitle surface is
    // hidden, preventing the built-in listener from racing a delayed correction.
    private var subripSelected = false

    private val listener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            val format = tracks.groups
                .firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.isSelected }
                ?.let { g -> (0 until g.length).firstOrNull { g.isTrackSelected(it) }?.let(g::getTrackFormat) }
            videoFps = format?.frameRate?.takeIf { it > 0f } ?: 0f
            estimateDone = videoFps > 0f
            synchronized(frameTimes) { frameTimes.clear() }
            applyHdr(format)
            applyFrameRate()
            val audio = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.isSelected }
                ?.let { group -> (0 until group.length).firstOrNull { group.isTrackSelected(it) }?.let(group::getTrackFormat) }
            audioInputFormat = audio?.let { "${it.sampleMimeType} codecs=${it.codecs ?: "?"} ${it.channelCount}ch" } ?: "none selected"
            recordEvent("Selected audio: $audioInputFormat")
            selectBestAudioIfNeeded(tracks)
            subripSelected = tracks.groups.any { group ->
                group.type == C.TRACK_TYPE_TEXT &&
                    (0 until group.length).any { index ->
                        group.isTrackSelected(index) &&
                            group.getTrackFormat(index).sampleMimeType == MimeTypes.APPLICATION_SUBRIP
                    }
            }
            singleSubtitleView.setCues(emptyList())
            // SubtitleView may be refreshed when tracks change; restore the saved user size.
            restoreSubtitleStyleAfterRefresh()
        }

        override fun onCues(cueGroup: CueGroup) {
            // Render synchronously to our sole subtitle surface. For SRT, separate
            // overlapping cue objects are collapsed; embedded newlines inside one
            // cue (legitimate two-line dialogue) remain untouched.
            val cues = cueGroup.cues
            val shown = if (subripSelected && cues.size > 1 && cues.all { it.text != null }) {
                listOf(cues.lastOrNull { !it.text.isNullOrBlank() } ?: cues.last())
            } else cues
            singleSubtitleView.setCues(shown)
        }

        override fun onRenderedFirstFrame() {
            // Start with a clean picture. A tap on the video reveals PlayerView controls.
            recordEvent("First video frame; controls=${controlPanel.visibility == View.VISIBLE}")
            infoText.visibility = View.GONE
        }

        override fun onPlaybackStateChanged(state: Int) {
            recordEvent("Playback state=$state; controls=${controlPanel.visibility == View.VISIBLE}")
            if (state == Player.STATE_ENDED) {
                ended = true
                clearProgress()
                // When another app (e.g. Plezy) launched us, hand control back when the video finishes.
                if (launchedExternally) finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::playerView.isInitialized) restoreSubtitleStyleAfterRefresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        playerView = findViewById(R.id.playerView)
        singleSubtitleView = findViewById(R.id.singleSubtitleView)
        // PlayerView continues to own video and audio, but never draws subtitles.
        playerView.subtitleView?.visibility = View.GONE
        // Do not automatically show controls when playback starts. A tap reveals them;
        // PlayerView hides them again after this timeout.
        playerView.useController = false
        playerView.controllerAutoShow = false
        playerView.controllerShowTimeoutMs = 3000
        revealControls = findViewById(R.id.revealControls)
        revealControls.setOnClickListener { revealControls() }
        openButton = findViewById(R.id.openButton)
        infoText = findViewById(R.id.infoText)
        subtitleButton = findViewById(R.id.subtitleButton)
        // Always reachable from the manually revealed transport panel.
        findViewById<Button>(R.id.audioSettingsButton).setOnClickListener { showAudioTracksDialog() }
        subtitleButton.setOnClickListener { showSubtitleDialog() }
        controlPanel = findViewById(R.id.controlPanel)
        playPauseButton = findViewById(R.id.playPauseButton)
        rewindButton = findViewById(R.id.rewindButton)
        forwardButton = findViewById(R.id.forwardButton)
        seekSettingsButton = findViewById(R.id.seekSettingsButton)
        playPauseButton.setOnClickListener {
            player?.let { it.playWhenReady = !it.playWhenReady }
            refreshPlayButton(); scheduleHide()
        }
        rewindButton.setOnClickListener { player?.let { it.seekTo((it.currentPosition - seekBackSeconds * 1000L).coerceAtLeast(0L)) }; scheduleHide() }
        forwardButton.setOnClickListener { player?.let {
            val target = it.currentPosition + seekForwardSeconds * 1000L
            it.seekTo(if (it.duration > 0L) target.coerceAtMost(it.duration) else target)
        }; scheduleHide() }
        seekSettingsButton.setOnClickListener { showSeekSettingsDialog() }
        refreshSeekLabels()
        concealControls("startup")
        applySubtitleSize()
        openButton.setOnClickListener { picker.launch(arrayOf("video/*", "audio/*")) }

        (playerView.videoSurfaceView as? SurfaceView)?.holder?.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = applyFrameRate()
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })

        savedInstanceState?.let {
            uri = it.getString("uri")?.let(Uri::parse)
            position = it.getLong("pos")
            playWhenReady = it.getBoolean("play", true)
        }
        launchedExternally = intent?.action == Intent.ACTION_VIEW
        // Reconstruct the same identity after activity recreation so saves and restores
        // always address the same entry in SharedPreferences.
        if (uri != null) activeIdentity = identityFor(uri!!, intent)
        if (uri == null) {
            uri = intent?.takeIf { it.action == Intent.ACTION_VIEW }?.data
            uri?.let { activeIdentity = identityFor(it, intent); position = startingPosition(it, intent) }
        }
        applyImmersive(resources.configuration)
        // Skip the empty launch screen: go straight to the system file picker.
        if (uri == null && savedInstanceState == null) {
            openButton.visibility = View.GONE
            playerView.post { if (uri == null && player == null) picker.launch(arrayOf("video/*", "audio/*")) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let {
            launchedExternally = intent.action == Intent.ACTION_VIEW
            releasePlayer() // Save outgoing URI and identity BEFORE replacing them.
            setIntent(intent)
            uri = it; activeIdentity = identityFor(it, intent); position = startingPosition(it, intent); ended = false
            playWhenReady = true
            recordEvent("New intent restored position=$position ms")
            startPlayer()
        }
    }

    override fun onStart() {
        super.onStart()
        startPlayer()
        progressHandler.removeCallbacks(progressSaver)
        progressHandler.postDelayed(progressSaver, 5000L)
    }
    override fun onPause() {
        saveProgress()
        super.onPause()
    }
    override fun onStop() {
        saveProgress()
        progressHandler.removeCallbacks(progressSaver)
        releasePlayer()
        super.onStop()
    }

    // Plex streaming URLs can carry changing tokens, while display titles can vary.
    // Prefer a stable Plex media/part identifier from the path or caller metadata.
    private fun identityFor(u: Uri, source: Intent?): String {
        val path = u.path.orEmpty()
        val plexId = Regex("/(?:library/)?(?:parts|metadata|media)/([0-9]+)").find(path)
            ?.groupValues?.get(1)
        if (plexId != null) return "plex:$plexId"
        val callerId = listOf("media_id", "ratingKey", "rating_key", "metadata_id", "key")
            .firstNotNullOfOrNull { key -> source?.getStringExtra(key)?.takeIf { it.isNotBlank() } }
        if (callerId != null) return "media:$callerId"
        // Ignore ephemeral URL query parameters (tokens, auth, timestamps).
        // Do not use title as the primary identity: titles can differ across launches.
        return "url:${u.scheme}://${u.authority}${u.path}"
    }

    private fun progressKey(u: Uri): String {
        val identity = activeIdentity ?: identityFor(u, null)
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun startingPosition(u: Uri, source: Intent?): Long {
        val supplied = listOf("position", "extra_position", "start_position", "startPosition", "resume_position", "resumePosition")
            .firstNotNullOfOrNull { key ->
                if (source?.hasExtra(key) == true) {
                    when (val v = source.extras?.get(key)) {
                        is Number -> v.toLong()
                        is String -> v.toLongOrNull()
                        else -> null
                    }
                } else null
            }
        externalStartPosition = supplied?.coerceAtLeast(0L) ?: 0L
        // A caller's explicit zero can be a default placeholder, not a user
        // request to discard an existing local resume point.
        val local = restoredPosition(u)
        return if (supplied != null && supplied > 0L) supplied else local
    }

    private fun restoredPosition(u: Uri): Long =
        getSharedPreferences("playback_progress", MODE_PRIVATE).getLong(progressKey(u), 0L)

    private fun clearProgress() {
        uri?.let { getSharedPreferences("playback_progress", MODE_PRIVATE).edit().remove(progressKey(it)).apply() }
    }

    private fun saveProgress() {
        val u = uri ?: return
        val p = player ?: return
        val duration = p.duration
        if (duration > 0 && duration != C.TIME_UNSET) lastKnownDuration = duration
        if (ended || p.playbackState == Player.STATE_ENDED) {
            clearProgress()
            recordEvent("Progress cleared (completed/near end)")
        } else if (p.currentPosition > 0L) {
            getSharedPreferences("playback_progress", MODE_PRIVATE).edit()
                .putLong(progressKey(u), p.currentPosition).commit()
            recordEvent("Progress saved=${p.currentPosition} ms")
        }
    }

    // Report back to the calling app (Plezy, MX Player-style and VLC-style results).
    override fun finish() {
        saveProgress()
        if (launchedExternally) {
            val pos = player?.currentPosition ?: position
            val dur = player?.duration?.takeIf { it > 0 && it != C.TIME_UNSET } ?: lastKnownDuration
            setResult(RESULT_OK, Intent("org.videolan.vlc.player.result").apply {
                putExtra("end_by", if (ended) "playback_completion" else "user")
                putExtra("position", pos.toInt())
                putExtra("playback_position", pos)
                putExtra("duration", dur.toInt())
                putExtra("extra_position", pos)
                putExtra("extra_duration", dur)
            })
        }
        super.finish()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        player?.let { position = it.currentPosition; playWhenReady = it.playWhenReady }
        out.putString("uri", uri?.toString())
        out.putLong("pos", position)
        out.putBoolean("play", playWhenReady)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyImmersive(newConfig)
    }

    private fun startPlayer() {
        val u = uri ?: return
        if (player != null) return
        manualAudioChoice = false
        lastAutoAudioKey = null
        openButton.visibility = View.GONE

        val passthroughEnabled = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("audioPassthrough", true)
        audioDecoderName = "not reported"
        audioInputFormat = "not selected"
        recordEvent("Player starting: auto passthrough=$passthroughEnabled, resume=$position ms")
        // For Auto passthrough, exclude the FFmpeg extension audio decoder.
        // The Android core audio renderer can send encoded audio to DefaultAudioSink
        // when the HDMI route advertises support; it may still decode to PCM otherwise.
        // The PCM mode retains its separately configured audio sink.
        val factory: DefaultRenderersFactory = if (passthroughEnabled) {
            // Shield TV / HDMI: Nova's "Force passthrough" works even when
            // Android's reported HDMI capabilities are incomplete. Tell the
            // Media3 audio sink which compressed formats to attempt directly.
            // Use the no-context builder deliberately: a context-backed sink
            // re-queries Android's capabilities and ignores this override.
            object : DefaultRenderersFactory(this@MainActivity) {
                override fun buildAudioSink(
                    context: android.content.Context,
                    enableFloatOutput: Boolean,
                    enableAudioOutputPlaybackParams: Boolean
                ): AudioSink {
                    val forced = AudioCapabilities(
                        intArrayOf(
                            C.ENCODING_PCM_16BIT,
                            C.ENCODING_AC3,
                            C.ENCODING_E_AC3,
                            C.ENCODING_E_AC3_JOC,
                            C.ENCODING_DTS,
                            C.ENCODING_DTS_HD,
                            C.ENCODING_DOLBY_TRUEHD
                        ),
                        8
                    )
                    return DefaultAudioSink.Builder(this@MainActivity)
                        .setAudioOutputProvider(
                            IecAudioOutputProvider(
                                AudioTrackAudioOutputProvider.Builder(this@MainActivity).build()
                            )
                        )
                        .setEnableFloatOutput(false)
                        .build()
                }
            }.apply {
                // Keep MediaCodec video rendering unchanged; don't let the
                // FFmpeg extension turn compressed audio into PCM first.
                setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
                setEnableDecoderFallback(true)
                setEnableAudioFloatOutput(false)
            }
        } else {
            object : DefaultRenderersFactory(this@MainActivity) {
                override fun buildAudioSink(
                    context: android.content.Context,
                    enableFloatOutput: Boolean,
                    enableAudioOutputPlaybackParams: Boolean
                ): AudioSink {
                    return DefaultAudioSink.Builder()
                        .setAudioCapabilities(AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES)
                        .build()
                }
            }.apply {
                setEnableDecoderFallback(true)
            }
        }

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        player = ExoPlayer.Builder(this, factory)
            .setAudioAttributes(audioAttrs, true)
            .build()
            .also {
                it.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF)
                it.setVideoFrameMetadataListener(frameListener)
                it.addListener(listener)
                it.addAnalyticsListener(audioAnalytics)
                playerView.player = it
                playerView.subtitleView?.visibility = View.GONE
                restoreSubtitleStyleAfterRefresh()
                it.setMediaItem(MediaItem.fromUri(u))
                it.seekTo(position)
                it.playWhenReady = playWhenReady
                it.prepare()
                // No playback-state callback is permitted to show controls.
            }
    }

    private fun releasePlayer() {
        singleSubtitleView.setCues(emptyList())
        subripSelected = false
        saveProgress()
        player?.let {
            position = it.currentPosition
            if (it.duration > 0 && it.duration != C.TIME_UNSET) lastKnownDuration = it.duration
            playWhenReady = it.playWhenReady
            it.release()
        }
        player = null
        playerView.player = null
        window.attributes = window.attributes.apply { preferredDisplayModeId = 0 }
        applyHdr(null)
    }

    // ---- Info readout (shows for a few seconds so you can see what is happening) --------------

    private fun showInfo() {
        val hz = window.decorView.display?.refreshRate ?: 0f
        val src = if (videoFps > 0f) String.format(Locale.US, "%.3f fps", videoFps) else "unknown"
        val sb = StringBuilder(String.format(Locale.US, "Video: %s  |  Screen: %.1f Hz", src, hz))
        player?.audioFormat?.let { f ->
            val codec = f.sampleMimeType?.substringAfter('/') ?: "?"
            val ch = if (f.channelCount > 0) "  ${f.channelCount}ch" else ""
            sb.append("\nAudio: ").append(codec).append(ch)
        }
        sb.append("\nOutput can pass through: ").append(passthroughSupport())
        infoText.text = sb.toString()
        infoText.visibility = View.VISIBLE
        infoText.removeCallbacks(hideInfo)
        infoText.postDelayed(hideInfo, 8000)
    }

    // Which bitstream formats the connected audio output (HDMI, USB, ...) accepts untouched.
    private fun passthroughSupport(): String {
        if (Build.VERSION.SDK_INT < 29) return "unknown (needs Android 10+)"
        val attrs = android.media.AudioAttributes.Builder()
            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MOVIE)
            .build()
        val formats = listOf(
            "AC3" to AudioFormat.ENCODING_AC3,
            "E-AC3" to AudioFormat.ENCODING_E_AC3,
            "DTS" to AudioFormat.ENCODING_DTS,
            "DTS-HD" to AudioFormat.ENCODING_DTS_HD,
            "TrueHD" to AudioFormat.ENCODING_DOLBY_TRUEHD
        )
        val ok = formats.filter { (_, enc) ->
            val f = AudioFormat.Builder()
                .setEncoding(enc)
                .setSampleRate(48000)
                .setChannelMask(AudioFormat.CHANNEL_OUT_5POINT1)
                .build()
            AudioTrack.isDirectPlaybackSupported(f, attrs)
        }.map { it.first }
        return if (ok.isEmpty()) "none (audio is decoded)" else ok.joinToString(", ")
    }

    private var manualAudioChoice = false
    private var lastAutoAudioKey: String? = null

    private fun audioQuality(f: Format): Int {
        val mime = f.sampleMimeType.orEmpty().lowercase(Locale.US)
        val codec = f.codecs.orEmpty().lowercase(Locale.US)
        val tier = when {
            "dts.hd" in mime || "dts-hd" in codec -> 700
            "truehd" in mime || "mlp" in mime -> 700
            "flac" in mime || "alac" in mime || "raw" in mime -> 600
            "eac3" in mime || "e-ac3" in mime -> 400
            "dts" in mime -> 350
            "ac3" in mime -> 300
            else -> 100
        }
        val commentary = f.label.orEmpty().lowercase(Locale.US).let {
            "commentary" in it || "description" in it || "descriptive" in it
        }
        val languageBonus = if (f.language.equals("en", true) || f.language?.startsWith("en-", true) == true) 2000 else 0
        return languageBonus + tier + f.channelCount.coerceAtLeast(0).coerceAtMost(8) * 5 - if (commentary) 3000 else 0
    }

    private fun selectBestAudioIfNeeded(tracks: Tracks) {
        if (manualAudioChoice) return
        val choices = tracks.groups.flatMap { group ->
            if (group.type != C.TRACK_TYPE_AUDIO) emptyList() else
                (0 until group.length).filter { group.isTrackSupported(it) }
                    .map { index -> Triple(group, index, audioQuality(group.getTrackFormat(index))) }
        }
        val best = choices.maxByOrNull { it.third } ?: return
        val key = "${best.first.mediaTrackGroup.id}:${best.second}"
        if (key == lastAutoAudioKey) return
        lastAutoAudioKey = key
        player?.trackSelectionParameters = player!!.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(best.first.mediaTrackGroup, listOf(best.second)))
            .build()
    }

    private fun showAudioTracksDialog() {
        val current = player ?: return
        val choices = current.currentTracks.groups.flatMap { group ->
            if (group.type != C.TRACK_TYPE_AUDIO) emptyList() else
                (0 until group.length).filter { group.isTrackSupported(it) }
                    .map { index -> Pair(group, index) }
        }
        if (choices.isEmpty()) {
            showAudioModeDialog()
            return
        }
        val labels = choices.map { (group, index) ->
            val f = group.getTrackFormat(index)
            "${f.language ?: "Unknown"} · ${f.label ?: f.sampleMimeType ?: "Audio"} · ${f.channelCount}ch"
        }.toTypedArray()
        val selected = choices.indexOfFirst { (group, index) -> group.isTrackSelected(index) }
        AlertDialog.Builder(this).setTitle("Audio tracks")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                val (group, index) = choices[which]
                manualAudioChoice = true
                current.trackSelectionParameters = current.trackSelectionParameters.buildUpon()
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(index)))
                    .build()
                dialog.dismiss()
                scheduleHide()
            }
            .setNeutralButton("Auto best") { _, _ ->
                manualAudioChoice = false
                lastAutoAudioKey = null
                current.trackSelectionParameters = current.trackSelectionParameters.buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO).build()
                selectBestAudioIfNeeded(current.currentTracks)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAudioModeDialog() {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val current = if (prefs.getBoolean("audioPassthrough", true)) 0 else 1
        AlertDialog.Builder(this)
            .setTitle("Audio output")
            .setSingleChoiceItems(arrayOf("Auto passthrough (when supported)", "Decode to PCM (no passthrough)"), current) { dialog, which ->
                val enabled = which == 0
                prefs.edit().putBoolean("audioPassthrough", enabled).apply()
                recordEvent("Audio mode selected: auto passthrough=$enabled")
                dialog.dismiss()
                // Recreate the player so the selected output mode takes effect immediately.
                player?.let {
                    position = it.currentPosition
                    playWhenReady = it.playWhenReady
                    releasePlayer()
                    startPlayer()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // The controller is not attached until the user explicitly requests it. This avoids
    // the initial PlayerView controller flash during prepare/buffering/track changes.
    private fun concealControls(reason: String = "timeout/back") {
        recordEvent("Controls HIDDEN: $reason")
        playerView.removeCallbacks(hideControls)
        playerView.useController = false
        controlPanel.visibility = View.GONE
        subtitleButton.visibility = View.GONE
        revealControls.visibility = View.VISIBLE
    }

    private fun revealControls() {
        recordEvent("Controls SHOWN: user action")
        revealControls.visibility = View.GONE
        controlPanel.visibility = View.VISIBLE
        refreshPlayButton()
        subtitleButton.visibility = View.VISIBLE
        // TV D-pad: OK must focus Play/Pause, never the rewind button.
        playPauseButton.isFocusableInTouchMode = true
        playPauseButton.requestFocus()
        scheduleHide()
    }

    private fun scheduleHide() {
        playerView.removeCallbacks(hideControls)
        playerView.postDelayed(hideControls, 3000L)
    }

    private fun refreshPlayButton() {
        playPauseButton.text = if (player?.playWhenReady == true) "Pause" else "Play"
    }

    // Return to the activity that launched us; never open another media URL or
    // relaunch the Plex server when the user presses Back.
    private fun exitToCaller() {
        saveProgress()
        player?.playWhenReady = false
        finish()
    }

    // Catch remote Back before the player view or its controls can consume it.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) exitToCaller()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Handled explicitly for Android TV remote Back")
    override fun onBackPressed() {
        exitToCaller()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // With the overlay hidden, LEFT/RIGHT seek without showing controls.
        // When controls are open, retain standard D-pad navigation and focus.
        if (controlPanel.visibility != View.VISIBLE && event.repeatCount == 0) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    player?.let { it.seekTo((it.currentPosition - seekBackSeconds * 1000L).coerceAtLeast(0L)) }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    player?.let {
                        val end = it.duration.takeIf { duration -> duration > 0 } ?: Long.MAX_VALUE
                        it.seekTo((it.currentPosition + seekForwardSeconds * 1000L).coerceAtMost(end))
                    }
                    return true
                }
            }
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitToCaller()
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            if (controlPanel.visibility != View.VISIBLE) {
                revealControls()
                return true
            }
        }
        if (controlPanel.visibility == View.VISIBLE) scheduleHide()
        return super.onKeyDown(keyCode, event)
    }

    // ---- Subtitle size -----------------------------------------------------------------------

    // Denser spacing between Small and Medium; stored separately so older indices
    // never silently select a different size after an app upgrade.
    private val subtitleSizes = floatArrayOf(0.012f, 0.017f, 0.022f, 0.028f, 0.034f, 0.040f, 0.046f, 0.0533f, 0.070f, 0.090f)
    private val subtitleNames = arrayOf("Tiny", "Very small", "Small", "Small +", "Medium -", "Medium", "Medium +", "Large", "Extra large", "Huge")
    private fun selectedSubtitleIndex(): Int {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        if (prefs.contains("subSizeV2")) return prefs.getInt("subSizeV2", 4).coerceIn(subtitleSizes.indices)
        if (!prefs.contains("subSize")) return 4 // Medium - is the first-run default.
        val old = prefs.getInt("subSize", 2).coerceIn(0, 6)
        return intArrayOf(0, 1, 2, 7, 8, 9, 9)[old]
    }

    private val seekChoices = intArrayOf(5, 10, 15, 20, 30, 60, 120)
    private val seekBackSeconds: Int get() = getSharedPreferences("settings", MODE_PRIVATE).getInt("seekBack", 10)
    private val seekForwardSeconds: Int get() = getSharedPreferences("settings", MODE_PRIVATE).getInt("seekForward", 30)

    private fun refreshSeekLabels() {
        rewindButton.text = "-${seekBackSeconds}s"
        forwardButton.text = "+${seekForwardSeconds}s"
    }

    private fun showSeekSettingsDialog() {
        val items = arrayOf("Rewind: ${seekBackSeconds}s", "Forward: ${seekForwardSeconds}s")
        AlertDialog.Builder(this).setTitle("Skip intervals")
            .setItems(items) { _, which ->
                val key = if (which == 0) "seekBack" else "seekForward"
                val current = if (which == 0) seekBackSeconds else seekForwardSeconds
                val labels = seekChoices.map { "${it} seconds" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle(if (which == 0) "Rewind interval" else "Forward interval")
                    .setSingleChoiceItems(labels, seekChoices.indexOf(current)) { dialog, index ->
                        getSharedPreferences("settings", MODE_PRIVATE).edit()
                            .putInt(key, seekChoices[index]).apply()
                        refreshSeekLabels()
                        dialog.dismiss()
                        scheduleHide()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }.setNegativeButton("Cancel", null).show()
    }

    // Media3 may recreate/refresh SubtitleView styling after a player attach or cue update.
    // Reapply the persisted preference on the next frame and after the refresh settles.
    private fun restoreSubtitleStyleAfterRefresh() {
        applySubtitleSize()
        playerView.post { applySubtitleSize() }
        playerView.postDelayed({ applySubtitleSize() }, 250L)
        playerView.postDelayed({ applySubtitleSize() }, 1000L)
    }

    private fun applySubtitleSize() {
        val idx = selectedSubtitleIndex()
        singleSubtitleView.apply {
            setApplyEmbeddedStyles(false)
            setApplyEmbeddedFontSizes(false)
            setFractionalTextSize(subtitleSizes[idx])
        }
    }

    private fun showSubtitleDialog() {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        AlertDialog.Builder(this)
            .setTitle("Subtitle size")
            .setSingleChoiceItems(subtitleNames, selectedSubtitleIndex()) { d, which ->
                prefs.edit().putInt("subSizeV2", which).commit()
                recordEvent("Subtitle size selected: ${subtitleNames[which]} ($which)")
                restoreSubtitleStyleAfterRefresh()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    private val hideInfo = Runnable { infoText.visibility = View.GONE }

    // ---- HDR -------------------------------------------------------------------------------

    private fun applyHdr(format: Format?) {
        if (Build.VERSION.SDK_INT < 26) return
        val transfer = format?.colorInfo?.colorTransfer
        val hdr = transfer == C.COLOR_TRANSFER_ST2084 ||
            transfer == C.COLOR_TRANSFER_HLG ||
            format?.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION
        window.colorMode = if (hdr) ActivityInfo.COLOR_MODE_HDR else ActivityInfo.COLOR_MODE_DEFAULT
    }

    // ---- Frame-rate matching -----------------------------------------------------------------

    private fun snapFps(raw: Float): Float {
        val common = floatArrayOf(23.976f, 24f, 25f, 29.97f, 30f, 47.952f, 48f, 50f, 59.94f, 60f)
        val best = common.minByOrNull { abs(it - raw) / it } ?: return raw
        return if (abs(best - raw) / best < 0.02f) best else raw
    }

    private fun applyFrameRate() {
        val fps = videoFps
        if (fps <= 0f) return
        val surface = (playerView.videoSurfaceView as? SurfaceView)?.holder?.surface
        if (surface == null || !surface.isValid) return
        when {
            Build.VERSION.SDK_INT >= 31 -> surface.setFrameRate(
                fps, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE, Surface.CHANGE_FRAME_RATE_ALWAYS
            )
            Build.VERSION.SDK_INT >= 30 -> {
                surface.setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)
                pickDisplayMode(fps)
            }
            else -> pickDisplayMode(fps)
        }
    }

    private fun pickDisplayMode(fps: Float) {
        val display = window.decorView.display ?: return
        val cur = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .minByOrNull { m ->
                val k = (m.refreshRate / fps).roundToInt().coerceAtLeast(1)
                abs(m.refreshRate - fps * k) * 100f + k
            } ?: return
        window.attributes = window.attributes.apply { preferredDisplayModeId = best.modeId }
    }

    private fun applyImmersive(cfg: Configuration) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (cfg.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }
}
