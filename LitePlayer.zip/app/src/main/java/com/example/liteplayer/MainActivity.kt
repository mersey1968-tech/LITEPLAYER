package com.example.liteplayer

import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var openButton: Button
    private var player: ExoPlayer? = null

    private var uri: Uri? = null
    private var position = 0L
    private var playWhenReady = true
    private var videoFps = 0f

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) {
        it?.let { picked ->
            runCatching {
                contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            uri = picked; position = 0L; playWhenReady = true
            releasePlayer(); startPlayer()
        }
    }

    private val listener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            val format = tracks.groups
                .firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.isSelected }
                ?.let { g -> (0 until g.length).firstOrNull { g.isTrackSelected(it) }?.let(g::getTrackFormat) }
            videoFps = format?.frameRate?.takeIf { it > 0f } ?: 0f
            applyHdr(format)
            applyFrameRate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        playerView = findViewById(R.id.playerView)
        openButton = findViewById(R.id.openButton)
        openButton.setOnClickListener { picker.launch(arrayOf("video/*", "audio/*")) }

        // Re-apply frame rate whenever the video surface is (re)created.
        (playerView.videoSurfaceView as? SurfaceView)?.holder?.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = applyFrameRate()
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })

        savedInstanceState?.let {
            uri = it.getString("uri")?.let(Uri::parse)
            position = it.getLong("pos")
            playWhenReady = it.getBoolean("play", true)
        }
        if (uri == null) uri = intent?.takeIf { it.action == Intent.ACTION_VIEW }?.data
        applyImmersive(resources.configuration)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let { uri = it; position = 0L; releasePlayer(); startPlayer() }
    }

    override fun onStart() { super.onStart(); startPlayer() }
    override fun onStop() { super.onStop(); releasePlayer() }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        player?.let { position = it.currentPosition; playWhenReady = it.playWhenReady }
        out.putString("uri", uri?.toString())
        out.putLong("pos", position)
        out.putBoolean("play", playWhenReady)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyImmersive(newConfig)
    }

    private fun startPlayer() {
        val u = uri ?: return
        if (player != null) return
        openButton.visibility = View.GONE

        // Hardware decoders first; FFmpeg only where MediaCodec can't decode (ALAC, TrueHD, exotic profiles).
        val factory = NextRenderersFactory(this)
        factory.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        factory.setEnableDecoderFallback(true)
        // 24/32-bit PCM goes out as float instead of being truncated to 16-bit.
        factory.setEnableAudioFloatOutput(true)

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        player = ExoPlayer.Builder(this, factory)
            .setAudioAttributes(audioAttrs, true)
            .build()
            .also {
                // We drive frame-rate switching ourselves (see applyFrameRate).
                it.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF)
                it.addListener(listener)
                playerView.player = it
                it.setMediaItem(MediaItem.fromUri(u))
                it.seekTo(position)
                it.playWhenReady = playWhenReady
                it.prepare()
            }
    }

    private fun releasePlayer() {
        player?.let { position = it.currentPosition; playWhenReady = it.playWhenReady; it.release() }
        player = null
        playerView.player = null
        // Restore the display's normal mode and colour mode.
        window.attributes = window.attributes.apply { preferredDisplayModeId = 0 }
        applyHdr(null)
    }

    // ---- HDR -------------------------------------------------------------------------------

    private fun applyHdr(format: Format?) {
        if (Build.VERSION.SDK_INT < 26) return
        val transfer = format?.colorInfo?.colorTransfer
        val hdr = transfer == C.COLOR_TRANSFER_ST2084 ||
            transfer == C.COLOR_TRANSFER_HLG ||
            format?.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION
        window.colorMode = if (hdr) ActivityInfo.COLOR_MODE_HDR else ActivityInfo.COLOR_MODE_DEFAULT
    }

    // ---- Frame-rate matching -----------------------------------------------------------------

    private fun applyFrameRate() {
        val fps = videoFps
        if (fps <= 0f) return
        val surface = (playerView.videoSurfaceView as? SurfaceView)?.holder?.surface
        if (surface == null || !surface.isValid) return
        when {
            Build.VERSION.SDK_INT >= 31 -> surface.setFrameRate(
                fps, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE, Surface.CHANGE_FRAME_RATE_ALWAYS
            )
            Build.VERSION.SDK_INT >= 30 -> {
                surface.setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)
                pickDisplayMode(fps)
            }
            else -> pickDisplayMode(fps)
        }
    }

    // Pre-Android 12: choose the display mode whose refresh rate is the closest integer multiple of the video fps.
    private fun pickDisplayMode(fps: Float) {
        val display = window.decorView.display ?: return
        val cur = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .minByOrNull { m ->
                val k = (m.refreshRate / fps).roundToInt().coerceAtLeast(1)
                abs(m.refreshRate - fps * k) * 100f + k
            } ?: return
        window.attributes = window.attributes.apply { preferredDisplayModeId = best.modeId }
    }

    private fun applyImmersive(cfg: Configuration) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (cfg.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }
}
