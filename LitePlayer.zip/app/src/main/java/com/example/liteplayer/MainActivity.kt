package com.example.liteplayer

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.video.VideoFrameMetadataListener
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var openButton: Button
    private lateinit var infoText: TextView
    private lateinit var subtitleButton: Button
    private var player: ExoPlayer? = null

    private var uri: Uri? = null
    private var position = 0L
    private var playWhenReady = true

    @Volatile private var videoFps = 0f
    @Volatile private var estimateDone = false
    private val frameTimes = ArrayList<Long>()

    private var launchedExternally = false
    private var ended = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) {
        it?.let { picked ->
            runCatching {
                contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            uri = picked; position = 0L; playWhenReady = true
            releasePlayer(); startPlayer()
        }
    }

    // Fallback for streams that don't declare a frame rate: measure it from the first decoded frames.
    private val frameListener = VideoFrameMetadataListener { pts, _, _, _ ->
        if (!estimateDone && videoFps <= 0f) {
            var fps = 0f
            synchronized(frameTimes) {
                frameTimes.add(pts)
                if (frameTimes.size >= 48) {
                    val sorted = frameTimes.sorted()
                    val span = sorted.last() - sorted.first()
                    if (span > 0) fps = snapFps((sorted.size - 1) * 1_000_000f / span)
                    frameTimes.clear()
                    estimateDone = true
                }
            }
            val found = fps
            if (found > 0f) runOnUiThread { videoFps = found; applyFrameRate() }
        }
    }

    private val listener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            val format = tracks.groups
                .firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.isSelected }
                ?.let { g -> (0 until g.length).firstOrNull { g.isTrackSelected(it) }?.let(g::getTrackFormat) }
            videoFps = format?.frameRate?.takeIf { it > 0f } ?: 0f
            estimateDone = videoFps > 0f
            synchronized(frameTimes) { frameTimes.clear() }
            applyHdr(format)
            applyFrameRate()
        }

        override fun onRenderedFirstFrame() {
            infoText.postDelayed({ showInfo() }, 1500)
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) {
                ended = true
                // When another app (e.g. Plezy) launched us, hand control back when the video finishes.
                if (launchedExternally) finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        playerView = findViewById(R.id.playerView)
        openButton = findViewById(R.id.openButton)
        infoText = findViewById(R.id.infoText)
        subtitleButton = findViewById(R.id.subtitleButton)
        subtitleButton.setOnClickListener { showSubtitleDialog() }
        // Show the subtitle-size button only while the playback controls are visible.
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            subtitleButton.visibility = if (v == View.VISIBLE && player != null) View.VISIBLE else View.GONE
        })
        applySubtitleSize()
        openButton.setOnClickListener { picker.launch(arrayOf("video/*", "audio/*")) }

        (playerView.videoSurfaceView as? SurfaceView)?.holder?.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = applyFrameRate()
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })

        savedInstanceState?.let {
            uri = it.getString("uri")?.let(Uri::parse)
            position = it.getLong("pos")
            playWhenReady = it.getBoolean("play", true)
        }
        launchedExternally = intent?.action == Intent.ACTION_VIEW
        if (uri == null) uri = intent?.takeIf { it.action == Intent.ACTION_VIEW }?.data
        applyImmersive(resources.configuration)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let {
            launchedExternally = intent.action == Intent.ACTION_VIEW
            uri = it; position = 0L; ended = false
            releasePlayer(); startPlayer()
        }
    }

    override fun onStart() { super.onStart(); startPlayer() }
    override fun onStop() { super.onStop(); releasePlayer() }

    // Report back to the calling app (Plezy, MX Player-style and VLC-style results).
    override fun finish() {
        if (launchedExternally) {
            val pos = player?.currentPosition ?: position
            val dur = player?.duration?.takeIf { it != C.TIME_UNSET } ?: 0L
            setResult(RESULT_OK, Intent("org.videolan.vlc.player.result").apply {
                putExtra("end_by", if (ended) "playback_completion" else "user")
                putExtra("position", pos.toInt())
                putExtra("duration", dur.toInt())
                putExtra("extra_position", pos)
                putExtra("extra_duration", dur)
            })
        }
        super.finish()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        player?.let { position = it.currentPosition; playWhenReady = it.playWhenReady }
        out.putString("uri", uri?.toString())
        out.putLong("pos", position)
        out.putBoolean("play", playWhenReady)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyImmersive(newConfig)
    }

    private fun startPlayer() {
        val u = uri ?: return
        if (player != null) return
        openButton.visibility = View.GONE

        val factory = NextRenderersFactory(this)
        factory.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        factory.setEnableDecoderFallback(true)
        factory.setEnableAudioFloatOutput(true)

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        player = ExoPlayer.Builder(this, factory)
            .setAudioAttributes(audioAttrs, true)
            .build()
            .also {
                it.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF)
                it.setVideoFrameMetadataListener(frameListener)
                it.addListener(listener)
                playerView.player = it
                it.setMediaItem(MediaItem.fromUri(u))
                it.seekTo(position)
                it.playWhenReady = playWhenReady
                it.prepare()
            }
    }

    private fun releasePlayer() {
        player?.let { position = it.currentPosition; playWhenReady = it.playWhenReady; it.release() }
        player = null
        playerView.player = null
        window.attributes = window.attributes.apply { preferredDisplayModeId = 0 }
        applyHdr(null)
    }

    // ---- Info readout (shows for a few seconds so you can see what is happening) --------------

    private fun showInfo() {
        val hz = window.decorView.display?.refreshRate ?: 0f
        val src = if (videoFps > 0f) String.format(Locale.US, "%.3f fps", videoFps) else "unknown"
        val sb = StringBuilder(String.format(Locale.US, "Video: %s  |  Screen: %.1f Hz", src, hz))
        player?.audioFormat?.let { f ->
            val codec = f.sampleMimeType?.substringAfter('/') ?: "?"
            val ch = if (f.channelCount > 0) "  ${f.channelCount}ch" else ""
            sb.append("\nAudio: ").append(codec).append(ch)
        }
        sb.append("\nOutput can pass through: ").append(passthroughSupport())
        infoText.text = sb.toString()
        infoText.visibility = View.VISIBLE
        infoText.removeCallbacks(hideInfo)
        infoText.postDelayed(hideInfo, 8000)
    }

    // Which bitstream formats the connected audio output (HDMI, USB, ...) accepts untouched.
    private fun passthroughSupport(): String {
        if (Build.VERSION.SDK_INT < 29) return "unknown (needs Android 10+)"
        val attrs = android.media.AudioAttributes.Builder()
            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MOVIE)
            .build()
        val formats = listOf(
            "AC3" to AudioFormat.ENCODING_AC3,
            "E-AC3" to AudioFormat.ENCODING_E_AC3,
            "DTS" to AudioFormat.ENCODING_DTS,
            "DTS-HD" to AudioFormat.ENCODING_DTS_HD,
            "TrueHD" to AudioFormat.ENCODING_DOLBY_TRUEHD
        )
        val ok = formats.filter { (_, enc) ->
            val f = AudioFormat.Builder()
                .setEncoding(enc)
                .setSampleRate(48000)
                .setChannelMask(AudioFormat.CHANNEL_OUT_5POINT1)
                .build()
            AudioTrack.isDirectPlaybackSupported(f, attrs)
        }.map { it.first }
        return if (ok.isEmpty()) "none (audio is decoded)" else ok.joinToString(", ")
    }

    // ---- Subtitle size -----------------------------------------------------------------------

    private val subtitleSizes = floatArrayOf(0.04f, 0.0533f, 0.07f, 0.09f, 0.115f)
    private val subtitleNames = arrayOf("Small", "Default", "Large", "Extra large", "Huge")

    private fun applySubtitleSize() {
        val idx = getSharedPreferences("settings", MODE_PRIVATE).getInt("subSize", 1).coerceIn(0, 4)
        playerView.subtitleView?.apply {
            setApplyEmbeddedFontSizes(false)
            setFractionalTextSize(subtitleSizes[idx])
        }
    }

    private fun showSubtitleDialog() {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        AlertDialog.Builder(this)
            .setTitle("Subtitle size")
            .setSingleChoiceItems(subtitleNames, prefs.getInt("subSize", 1).coerceIn(0, 4)) { d, which ->
                prefs.edit().putInt("subSize", which).apply()
                applySubtitleSize()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private val hideInfo = Runnable { infoText.visibility = View.GONE }

    // ---- HDR -------------------------------------------------------------------------------

    private fun applyHdr(format: Format?) {
        if (Build.VERSION.SDK_INT < 26) return
        val transfer = format?.colorInfo?.colorTransfer
        val hdr = transfer == C.COLOR_TRANSFER_ST2084 ||
            transfer == C.COLOR_TRANSFER_HLG ||
            format?.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION
        window.colorMode = if (hdr) ActivityInfo.COLOR_MODE_HDR else ActivityInfo.COLOR_MODE_DEFAULT
    }

    // ---- Frame-rate matching -----------------------------------------------------------------

    private fun snapFps(raw: Float): Float {
        val common = floatArrayOf(23.976f, 24f, 25f, 29.97f, 30f, 47.952f, 48f, 50f, 59.94f, 60f)
        val best = common.minByOrNull { abs(it - raw) / it } ?: return raw
        return if (abs(best - raw) / best < 0.02f) best else raw
    }

    private fun applyFrameRate() {
        val fps = videoFps
        if (fps <= 0f) return
        val surface = (playerView.videoSurfaceView as? SurfaceView)?.holder?.surface
        if (surface == null || !surface.isValid) return
        when {
            Build.VERSION.SDK_INT >= 31 -> surface.setFrameRate(
                fps, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE, Surface.CHANGE_FRAME_RATE_ALWAYS
            )
            Build.VERSION.SDK_INT >= 30 -> {
                surface.setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)
                pickDisplayMode(fps)
            }
            else -> pickDisplayMode(fps)
        }
        infoText.postDelayed({ showInfo() }, 1500)
    }

    private fun pickDisplayMode(fps: Float) {
        val display = window.decorView.display ?: return
        val cur = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .minByOrNull { m ->
                val k = (m.refreshRate / fps).roundToInt().coerceAtLeast(1)
                abs(m.refreshRate - fps * k) * 100f + k
            } ?: return
        window.attributes = window.attributes.apply { preferredDisplayModeId = best.modeId }
    }

    private fun applyImmersive(cfg: Configuration) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (cfg.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }
}
