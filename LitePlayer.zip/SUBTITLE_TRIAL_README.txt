Subtitle-only isolated test based on srt_clean_style.
Separate applicationId, so it installs beside existing Lite Player.
One subtitle view, original cue text/spans/newlines, no text merging.
SRT overlapping cues: show newest nonempty cue. Other formats unchanged.
No changes to audio/video/transport/resume implementation.
This source ZIP has not been compiled or device-tested.
